import Base from "../Base/Base.js";
import ModelStorageManager from "./ModelBuilder/ModelStorageManager.js";
import ModelSubModulesBuilder from "./ModelBuilder/ModelSubModulesBuilder.js";
import ModelModulesBuilder from "./ModelBuilder/ModelModulesBuilder.js";
import ModelBuilderUserInterface from "./ModelBuilder/ModelBuilderUserInterface.js";


export default class ModelBuilderManager extends Base {
    static defaultId = 'rocket-designer-button';
    static currentId = ModelBuilderManager.defaultId;

    /**
     *
     * @param {string|null} id
     */
    constructor(id = null) {
        super();

        // Initialize the model builders and storage manager
        this.storageManager = new ModelStorageManager();
        this.subModulesBuilder = new ModelSubModulesBuilder();
        this.modulesBuilder = new ModelModulesBuilder();
        this.modelBuilderUI = null;

        ModelBuilderManager.currentId = id;

        this.init();
    }

    init() {
        if (null === ModelBuilderManager.currentId) {
            ModelBuilderManager.currentId = ModelBuilderManager.defaultId;
        }

        // Add event listener to the button
        let modelBuilderElement = document.getElementById(ModelBuilderManager.currentId);
        if (null === modelBuilderElement) {
            this.warn(`Model builder element with id ${ModelBuilderManager.currentId} not found. Skipping.`);
            return;
        }

        modelBuilderElement.addEventListener('click', () => {
            this.log("Opening model builder");

            if (!this.modelBuilderUI) {
                // Initialize the UI with the target element ID and the builders
                this.modelBuilderUI = new ModelBuilderUserInterface(
                    ModelBuilderManager.currentId,
                    this.modulesBuilder,
                    this.subModulesBuilder,
                    this.storageManager
                );
            }

            // Show the model builder interface
            this.modelBuilderUI.showModelBuilder();
        });
    }

    static click() {
         console.log("click");
         let element = document.getElementById(ModelBuilderManager.currentId);
         if (element) {
             element.click();
         } else {
             this.log(`element ${ModelBuilderManager.currentId} not found. Skipping Click.`);
         }

    }
}

/**
 *
 * @param {string|null} id
 */
window.initModelBuilder = function(id=null) {
    let modelBuilderManager = new ModelBuilderManager(id);
}

window.ModelBuilderManager = ModelBuilderManager;