
/**
 * Class for handling storage, import and export of the model data
 */
export default class ModelStorageManager {
    constructor() {
        this.storage = window.localStorage;
        this.storageKey = 'rocketModelData';
    }

    /**
     * Save the current model to local storage
     * @param {Object} modelData - The model data to save
     */
    saveModel(modelData) {
        this.storage.setItem(this.storageKey, JSON.stringify(modelData));
    }

    /**
     * Load the model from local storage
     * @returns {Object|null} The model data or null if none exists
     */
    loadModel() {
        const modelData = this.storage.getItem(this.storageKey);
        return modelData ? JSON.parse(modelData) : null;
    }

    /**
     * Export the model as a JSON file
     * @param {Object} modelData - The model data to export
     */
    exportModel(modelData) {
        const dataStr = JSON.stringify(modelData, null, 2);
        const dataUri = 'data:application/json;charset=utf-8,' + encodeURIComponent(dataStr);

        const exportFileName = 'rocket_model_' + new Date().getTime() + '.json';

        const linkElement = document.createElement('a');
        linkElement.setAttribute('href', dataUri);
        linkElement.setAttribute('download', exportFileName);
        linkElement.click();
    }

    /**
     * Import a model from a JSON file
     * @param {File} file - The JSON file to import
     * @returns {Promise<Object>} The imported model data
     */
    importModel(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();

            reader.onload = (event) => {
                try {
                    const modelData = JSON.parse(event.target.result);
                    resolve(modelData);
                } catch (error) {
                    reject(new Error('Invalid JSON file'));
                }
            };

            reader.onerror = () => {
                reject(new Error('Failed to read file'));
            };

            reader.readAsText(file);
        });
    }
}

window.ModelStorageManager = ModelStorageManager;