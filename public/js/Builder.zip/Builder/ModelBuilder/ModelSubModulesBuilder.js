
/**
 * Class for managing submodules in the rocket model
 */
export default class ModelSubModulesBuilder {
    constructor() {
        this.subModules = [];
    }

    /**
     * Get all submodules
     * @returns {Array} List of all submodules
     */
    getAllSubModules() {
        return this.subModules;
    }

    /**
     * Add a new submodule
     * @param {Object} subModuleData - The submodule data
     * @returns {Object} The newly created submodule
     */
    addSubModule(subModuleData) {
        const newSubModule = {
            id: 'submodule_' + Date.now(),
            name: subModuleData.name,
            description: subModuleData.description,
            type: subModuleData.type,
            specifications: subModuleData.specifications || {}
        };

        this.subModules.push(newSubModule);
        return newSubModule;
    }

    /**
     * Update an existing submodule
     * @param {string} subModuleId - The ID of the submodule to update
     * @param {Object} updatedData - The updated submodule data
     * @returns {Object|null} The updated submodule or null if not found
     */
    updateSubModule(subModuleId, updatedData) {
        const subModuleIndex = this.subModules.findIndex(sm => sm.id === subModuleId);

        if (subModuleIndex === -1) {
            return null;
        }

        this.subModules[subModuleIndex] = {
            ...this.subModules[subModuleIndex],
            ...updatedData
        };

        return this.subModules[subModuleIndex];
    }

    /**
     * Delete a submodule
     * @param {string} subModuleId - The ID of the submodule to delete
     * @returns {boolean} True if successful, false if not found
     */
    deleteSubModule(subModuleId) {
        const initialLength = this.subModules.length;
        this.subModules = this.subModules.filter(sm => sm.id !== subModuleId);
        return this.subModules.length < initialLength;
    }

    /**
     * Get a submodule by ID
     * @param {string} subModuleId - The ID of the submodule to retrieve
     * @returns {Object|null} The submodule or null if not found
     */
    getSubModuleById(subModuleId) {
        return this.subModules.find(sm => sm.id === subModuleId) || null;
    }

    /**
     * Set the submodules array (used for loading saved data)
     * @param {Array} subModulesArray - Array of submodules to set
     */
    setSubModules(subModulesArray) {
        if (Array.isArray(subModulesArray)) {
            this.subModules = subModulesArray;
        }
    }
}

window.ModelSubModulesBuilder = ModelSubModulesBuilder;