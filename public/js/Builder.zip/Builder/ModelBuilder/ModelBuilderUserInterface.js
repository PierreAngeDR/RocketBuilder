/**
 * Class for handling the user interface of the model builder
 */
export default class ModelBuilderUserInterface {
    /**
     * Create a new ModelBuilderUserInterface
     * @param {string} targetElementId - The ID of the HTML element to attach to
     * @param {ModelModulesBuilder} modulesBuilder - The modules builder instance
     * @param {ModelSubModulesBuilder} subModulesBuilder - The submodules builder instance
     * @param {ModelStorageManager} storageManager - The storage manager instance
     */
    constructor(targetElementId, modulesBuilder, subModulesBuilder, storageManager) {
        this.targetElement = document.getElementById(targetElementId);
        this.modulesBuilder = modulesBuilder;
        this.subModulesBuilder = subModulesBuilder;
        this.storageManager = storageManager;
        this.modalElement = null;
        this.isVisible = false;

        // Don't create a button automatically anymore - React will handle this
        // this.createOpenButton();
    }

    /**
     * Show the model builder interface
     */
    showModelBuilder() {
        console.log('showModelBuilder');
        if (this.isVisible) return;
        console.log('ok')

        // Create modal container
        this.modalElement = document.createElement('div');
        this.modalElement.className = 'model-builder-modal';

        // Create modal content
        const modalContent = document.createElement('div');
        modalContent.className = 'model-builder-modal-content';

        // Create header with title and close button
        const header = document.createElement('div');
        header.className = 'model-builder-header';

        const title = document.createElement('h2');
        title.textContent = 'Rocket Model Designer';

        const closeButton = document.createElement('button');
        closeButton.textContent = '×';
        closeButton.className = 'close-button';
        closeButton.onclick = () => this.hideModelBuilder();

        header.appendChild(title);
        header.appendChild(closeButton);

        // Create main content area
        const mainContent = document.createElement('div');
        mainContent.className = 'model-builder-main';

        // Create left panel (navigation)
        const leftPanel = document.createElement('div');
        leftPanel.className = 'model-builder-nav';

        const navItems = [
            { id: 'modules', label: 'Modules' },
            { id: 'submodules', label: 'Submodules' },
            { id: 'storage', label: 'Import/Export' }
        ];

        navItems.forEach(item => {
            const navButton = document.createElement('button');
            navButton.textContent = item.label;
            navButton.className = 'nav-button';
            navButton.dataset.section = item.id;
            navButton.onclick = (e) => this.switchSection(e.target.dataset.section);
            leftPanel.appendChild(navButton);
        });

        // Create right panel (content)
        const rightPanel = document.createElement('div');
        rightPanel.className = 'model-builder-content';

        // Create sections
        const modulesSection = this.createModulesSection();
        modulesSection.id = 'modules-section';

        const submodulesSection = this.createSubmodulesSection();
        submodulesSection.id = 'submodules-section';
        submodulesSection.style.display = 'none';

        const storageSection = this.createStorageSection();
        storageSection.id = 'storage-section';
        storageSection.style.display = 'none';

        rightPanel.appendChild(modulesSection);
        rightPanel.appendChild(submodulesSection);
        rightPanel.appendChild(storageSection);

        // Assemble the main content
        mainContent.appendChild(leftPanel);
        mainContent.appendChild(rightPanel);

        // Assemble the modal
        modalContent.appendChild(header);
        modalContent.appendChild(mainContent);
        this.modalElement.appendChild(modalContent);

        // Add modal to the page
        document.body.appendChild(this.modalElement);

        // Attach event handlers
        this.attachEventHandlers();

        // Mark as visible
        this.isVisible = true;
    }

    /**
     * Hide the model builder interface
     */
    hideModelBuilder() {
        if (this.modalElement) {
            document.body.removeChild(this.modalElement);
            this.modalElement = null;
            this.isVisible = false;
        }
    }

    /**
     * Switch between sections
     * @param {string} sectionId - The ID of the section to show
     */
    switchSection(sectionId) {
        const sections = ['modules-section', 'submodules-section', 'storage-section'];

        sections.forEach(section => {
            const element = document.getElementById(section);
            if (element) {
                element.style.display = section === `${sectionId}-section` ? 'block' : 'none';
            }
        });
    }

    /**
     * Create the modules section
     * @returns {HTMLElement} The modules section element
     */
    createModulesSection() {
        const section = document.createElement('div');
        section.className = 'section';

        const heading = document.createElement('h3');
        heading.textContent = 'Modules';

        // Form for adding a new module
        const form = document.createElement('form');
        form.id = 'add-module-form';
        form.className = 'form';

        const nameInput = document.createElement('input');
        nameInput.type = 'text';
        nameInput.name = 'name';
        nameInput.placeholder = 'Module Name';
        nameInput.required = true;

        const descInput = document.createElement('textarea');
        descInput.name = 'description';
        descInput.placeholder = 'Module Description';

        const typeSelect = document.createElement('select');
        typeSelect.name = 'type';
        ['Propulsion', 'Payload', 'Command', 'Structure', 'Other'].forEach(type => {
            const option = document.createElement('option');
            option.value = type.toLowerCase();
            option.textContent = type;
            typeSelect.appendChild(option);
        });

        const submitButton = document.createElement('button');
        submitButton.type = 'submit';
        submitButton.textContent = 'Add Module';

        form.appendChild(this.createFormField('Module Name:', nameInput));
        form.appendChild(this.createFormField('Description:', descInput));
        form.appendChild(this.createFormField('Type:', typeSelect));
        form.appendChild(submitButton);

        // List of existing modules
        const modulesList = document.createElement('div');
        modulesList.id = 'modules-list';
        modulesList.className = 'items-list';

        // Section for module details
        const moduleDetails = document.createElement('div');
        moduleDetails.id = 'module-details';
        moduleDetails.className = 'details-panel';

        // Assemble the section
        section.appendChild(heading);
        section.appendChild(form);
        section.appendChild(modulesList);
        section.appendChild(moduleDetails);

        return section;
    }

    /**
     * Create the submodules section
     * @returns {HTMLElement} The submodules section element
     */
    createSubmodulesSection() {
        const section = document.createElement('div');
        section.className = 'section';

        const heading = document.createElement('h3');
        heading.textContent = 'Submodules';

        // Form for adding a new submodule
        const form = document.createElement('form');
        form.id = 'add-submodule-form';
        form.className = 'form';

        const nameInput = document.createElement('input');
        nameInput.type = 'text';
        nameInput.name = 'name';
        nameInput.placeholder = 'Submodule Name';
        nameInput.required = true;

        const descInput = document.createElement('textarea');
        descInput.name = 'description';
        descInput.placeholder = 'Submodule Description';

        const typeSelect = document.createElement('select');
        typeSelect.name = 'type';
        ['Engine', 'Fuel Tank', 'Guidance', 'Communication', 'Power', 'Other'].forEach(type => {
            const option = document.createElement('option');
            option.value = type.toLowerCase();
            option.textContent = type;
            typeSelect.appendChild(option);
        });

        const submitButton = document.createElement('button');
        submitButton.type = 'submit';
        submitButton.textContent = 'Add Submodule';

        form.appendChild(this.createFormField('Submodule Name:', nameInput));
        form.appendChild(this.createFormField('Description:', descInput));
        form.appendChild(this.createFormField('Type:', typeSelect));
        form.appendChild(submitButton);

        // List of existing submodules
        const submodulesList = document.createElement('div');
        submodulesList.id = 'submodules-list';
        submodulesList.className = 'items-list';

        // Section for submodule details
        const submoduleDetails = document.createElement('div');
        submoduleDetails.id = 'submodule-details';
        submoduleDetails.className = 'details-panel';

        // Assemble the section
        section.appendChild(heading);
        section.appendChild(form);
        section.appendChild(submodulesList);
        section.appendChild(submoduleDetails);

        return section;
    }

    /**
     * Create the storage section
     * @returns {HTMLElement} The storage section element
     */
    createStorageSection() {
        const section = document.createElement('div');
        section.className = 'section';

        const heading = document.createElement('h3');
        heading.textContent = 'Import / Export';

        // Save Button
        const saveButton = document.createElement('button');
        saveButton.id = 'save-model-button';
        saveButton.textContent = 'Save Model';
        saveButton.className = 'action-button';

        // Load Button
        const loadButton = document.createElement('button');
        loadButton.id = 'load-model-button';
        loadButton.textContent = 'Load Model';
        loadButton.className = 'action-button';

        // Export Button
        const exportButton = document.createElement('button');
        exportButton.id = 'export-model-button';
        exportButton.textContent = 'Export Model';
        exportButton.className = 'action-button';

        // Import File Input
        const importContainer = document.createElement('div');
        importContainer.className = 'import-container';

        const importLabel = document.createElement('label');
        importLabel.htmlFor = 'import-model-file';
        importLabel.textContent = 'Import Model:';

        const importInput = document.createElement('input');
        importInput.type = 'file';
        importInput.id = 'import-model-file';
        importInput.accept = '.json';

        importContainer.appendChild(importLabel);
        importContainer.appendChild(importInput);

        // Assemble the section
        section.appendChild(heading);
        section.appendChild(saveButton);
        section.appendChild(loadButton);
        section.appendChild(exportButton);
        section.appendChild(importContainer);

        return section;
    }

    /**
     * Helper to create a form field with a label
     * @param {string} labelText - The label text
     * @param {HTMLElement} inputElement - The input element
     * @returns {HTMLElement} The form field container
     */
    createFormField(labelText, inputElement) {
        const container = document.createElement('div');
        container.className = 'form-field';

        const label = document.createElement('label');
        label.textContent = labelText;

        container.appendChild(label);
        container.appendChild(inputElement);

        return container;
    }

    /**
     * Attach event handlers to interactive elements
     */
    attachEventHandlers() {
        // Add module form submission
        const addModuleForm = document.getElementById('add-module-form');
        if (addModuleForm) {
            addModuleForm.addEventListener('submit', (e) => {
                e.preventDefault();
                const formData = new FormData(e.target);
                const moduleData = {
                    name: formData.get('name'),
                    description: formData.get('description'),
                    type: formData.get('type')
                };

                const newModule = this.modulesBuilder.addModule(moduleData);
                this.renderModulesList();
                e.target.reset();
            });
        }

        // Add submodule form submission
        const addSubmoduleForm = document.getElementById('add-submodule-form');
        if (addSubmoduleForm) {
            addSubmoduleForm.addEventListener('submit', (e) => {
                e.preventDefault();
                const formData = new FormData(e.target);
                const subModuleData = {
                    name: formData.get('name'),
                    description: formData.get('description'),
                    type: formData.get('type')
                };

                const newSubModule = this.subModulesBuilder.addSubModule(subModuleData);
                this.renderSubmodulesList();
                e.target.reset();
            });
        }

        // Storage section buttons
        const saveButton = document.getElementById('save-model-button');
        if (saveButton) {
            saveButton.addEventListener('click', () => {
                const modelData = {
                    modules: this.modulesBuilder.getAllModules(),
                    subModules: this.subModulesBuilder.getAllSubModules()
                };
                this.storageManager.saveModel(modelData);
                alert('Model saved successfully!');
            });
        }

        const loadButton = document.getElementById('load-model-button');
        if (loadButton) {
            loadButton.addEventListener('click', () => {
                const modelData = this.storageManager.loadModel();
                if (modelData) {
                    this.modulesBuilder.setModules(modelData.modules || []);
                    this.subModulesBuilder.setSubModules(modelData.subModules || []);
                    this.renderModulesList();
                    this.renderSubmodulesList();
                    alert('Model loaded successfully!');
                } else {
                    alert('No saved model found!');
                }
            });
        }

        const exportButton = document.getElementById('export-model-button');
        if (exportButton) {
            exportButton.addEventListener('click', () => {
                const modelData = {
                    modules: this.modulesBuilder.getAllModules(),
                    subModules: this.subModulesBuilder.getAllSubModules()
                };
                this.storageManager.exportModel(modelData);
            });
        }

        const importInput = document.getElementById('import-model-file');
        if (importInput) {
            importInput.addEventListener('change', (e) => {
                const file = e.target.files[0];
                if (file) {
                    this.storageManager.importModel(file)
                        .then(modelData => {
                            this.modulesBuilder.setModules(modelData.modules || []);
                            this.subModulesBuilder.setSubModules(modelData.subModules || []);
                            this.renderModulesList();
                            this.renderSubmodulesList();
                            alert('Model imported successfully!');
                        })
                        .catch(error => {
                            alert(`Import failed: ${error.message}`);
                        });
                }
            });
        }

        // Initial render of lists
        this.renderModulesList();
        this.renderSubmodulesList();
    }

    /**
     * Render the list of modules
     */
    renderModulesList() {
        const modulesList = document.getElementById('modules-list');
        if (!modulesList) return;

        modulesList.innerHTML = '';

        const modules = this.modulesBuilder.getAllModules();

        if (modules.length === 0) {
            const emptyMessage = document.createElement('p');
            emptyMessage.textContent = 'No modules created yet.';
            emptyMessage.className = 'empty-message';
            modulesList.appendChild(emptyMessage);
            return;
        }

        modules.forEach(module => {
            const moduleItem = document.createElement('div');
            moduleItem.className = 'item';
            moduleItem.dataset.id = module.id;

            const moduleName = document.createElement('span');
            moduleName.textContent = module.name;

            const viewButton = document.createElement('button');
            viewButton.textContent = 'View';
            viewButton.className = 'small-button';
            viewButton.onclick = () => this.showModuleDetails(module.id);

            moduleItem.appendChild(moduleName);
            moduleItem.appendChild(viewButton);

            modulesList.appendChild(moduleItem);
        });
    }

    /**
     * Render the list of submodules
     */
    renderSubmodulesList() {
        const submodulesList = document.getElementById('submodules-list');
        if (!submodulesList) return;

        submodulesList.innerHTML = '';

        const submodules = this.subModulesBuilder.getAllSubModules();

        if (submodules.length === 0) {
            const emptyMessage = document.createElement('p');
            emptyMessage.textContent = 'No submodules created yet.';
            emptyMessage.className = 'empty-message';
            submodulesList.appendChild(emptyMessage);
            return;
        }

        submodules.forEach(submodule => {
            const submoduleItem = document.createElement('div');
            submoduleItem.className = 'item';
            submoduleItem.dataset.id = submodule.id;

            const submoduleName = document.createElement('span');
            submoduleName.textContent = submodule.name;

            const viewButton = document.createElement('button');
            viewButton.textContent = 'View';
            viewButton.className = 'small-button';
            viewButton.onclick = () => this.showSubmoduleDetails(submodule.id);

            submoduleItem.appendChild(submoduleName);
            submoduleItem.appendChild(viewButton);

            submodulesList.appendChild(submoduleItem);
        });
    }

    /**
     * Show the details of a module
     * @param {string} moduleId - The ID of the module to show
     */
    showModuleDetails(moduleId) {
        const detailsPanel = document.getElementById('module-details');
        if (!detailsPanel) return;

        const module = this.modulesBuilder.getModuleById(moduleId);
        if (!module) return;

        detailsPanel.innerHTML = '';

        // Create the details content
        const name = document.createElement('h4');
        name.textContent = module.name;

        const type = document.createElement('p');
        type.textContent = `Type: ${module.type}`;

        const description = document.createElement('p');
        description.textContent = module.description || 'No description.';

        // Submodules section
        const submodulesHeading = document.createElement('h5');
        submodulesHeading.textContent = 'Submodules';

        const submodulesList = document.createElement('div');
        submodulesList.className = 'submodules-in-module';

        if (module.subModules.length === 0) {
            const emptySubmodules = document.createElement('p');
            emptySubmodules.textContent = 'No submodules attached.';
            emptySubmodules.className = 'empty-message';
            submodulesList.appendChild(emptySubmodules);
        } else {
            module.subModules.forEach(sm => {
                const submoduleItem = document.createElement('div');
                submoduleItem.className = 'submodule-item';

                const submoduleName = document.createElement('span');
                submoduleName.textContent = sm.name;

                const removeButton = document.createElement('button');
                removeButton.textContent = 'Remove';
                removeButton.className = 'small-button remove-button';
                removeButton.onclick = () => {
                    this.modulesBuilder.removeSubModuleFromModule(moduleId, sm.id);
                    this.showModuleDetails(moduleId); // Refresh
                };

                submoduleItem.appendChild(submoduleName);
                submoduleItem.appendChild(removeButton);

                submodulesList.appendChild(submoduleItem);
            });
        }

        // Add submodule selector
        const availableSubmodules = this.subModulesBuilder.getAllSubModules();
        const submoduleSelector = document.createElement('div');
        submoduleSelector.className = 'add-submodule-selector';

        if (availableSubmodules.length > 0) {
            const selectLabel = document.createElement('label');
            selectLabel.textContent = 'Add Submodule:';

            const select = document.createElement('select');
            select.id = `add-submodule-to-${moduleId}`;

            availableSubmodules.forEach(sm => {
                const option = document.createElement('option');
                option.value = sm.id;
                option.textContent = sm.name;
                select.appendChild(option);
            });

            const addButton = document.createElement('button');
            addButton.textContent = 'Add';
            addButton.className = 'small-button';
            addButton.onclick = () => {
                const selectElement = document.getElementById(`add-submodule-to-${moduleId}`);
                if (selectElement) {
                    const selectedSubmoduleId = selectElement.value;
                    const submodule = this.subModulesBuilder.getSubModuleById(selectedSubmoduleId);
                    if (submodule) {
                        this.modulesBuilder.addSubModuleToModule(moduleId, submodule);
                        this.showModuleDetails(moduleId); // Refresh
                    }
                }
            };

            submoduleSelector.appendChild(selectLabel);
            submoduleSelector.appendChild(select);
            submoduleSelector.appendChild(addButton);
        }

        // Actions for the module
        const actionsDiv = document.createElement('div');
        actionsDiv.className = 'actions';

        const deleteButton = document.createElement('button');
        deleteButton.textContent = 'Delete Module';
        deleteButton.className = 'action-button delete-button';
        deleteButton.onclick = () => {
            if (confirm(`Are you sure you want to delete "${module.name}"?`)) {
                this.modulesBuilder.deleteModule(moduleId);
                this.renderModulesList();
                detailsPanel.innerHTML = '';
            }
        };

        actionsDiv.appendChild(deleteButton);

        // Assemble the details panel
        detailsPanel.appendChild(name);
        detailsPanel.appendChild(type);
        detailsPanel.appendChild(description);
        detailsPanel.appendChild(document.createElement('hr'));
        detailsPanel.appendChild(submodulesHeading);
        detailsPanel.appendChild(submodulesList);
        detailsPanel.appendChild(submoduleSelector);
        detailsPanel.appendChild(document.createElement('hr'));
        detailsPanel.appendChild(actionsDiv);
    }

    /**
     * Show the details of a submodule
     * @param {string} subModuleId - The ID of the submodule to show
     */
    showSubmoduleDetails(subModuleId) {
        const detailsPanel = document.getElementById('submodule-details');
        if (!detailsPanel) return;

        const submodule = this.subModulesBuilder.getSubModuleById(subModuleId);
        if (!submodule) return;

        detailsPanel.innerHTML = '';

        // Create the details content
        const name = document.createElement('h4');
        name.textContent = submodule.name;

        const type = document.createElement('p');
        type.textContent = `Type: ${submodule.type}`;

        const description = document.createElement('p');
        description.textContent = submodule.description || 'No description.';

        // Actions for the submodule
        const actionsDiv = document.createElement('div');
        actionsDiv.className = 'actions';

        const deleteButton = document.createElement('button');
        deleteButton.textContent = 'Delete Submodule';
        deleteButton.className = 'action-button delete-button';
        deleteButton.onclick = () => {
            if (confirm(`Are you sure you want to delete "${submodule.name}"?`)) {
                this.subModulesBuilder.deleteSubModule(subModuleId);
                this.renderSubmodulesList();
                detailsPanel.innerHTML = '';
            }
        };

        actionsDiv.appendChild(deleteButton);

        // Assemble the details panel
        detailsPanel.appendChild(name);
        detailsPanel.appendChild(type);
        detailsPanel.appendChild(description);
        detailsPanel.appendChild(document.createElement('hr'));
        detailsPanel.appendChild(actionsDiv);
    }
}

window.ModelBuilderUserInterface = ModelBuilderUserInterface;