
/**
 * Class for managing modules in the rocket model
 */
export default class ModelModulesBuilder {
    constructor() {
        this.modules = [];
    }

    /**
     * Get all modules
     * @returns {Array} List of all modules
     */
    getAllModules() {
        return this.modules;
    }

    /**
     * Add a new module
     * @param {Object} moduleData - The module data
     * @returns {Object} The newly created module
     */
    addModule(moduleData) {
        const newModule = {
            id: 'module_' + Date.now(),
            name: moduleData.name,
            description: moduleData.description,
            type: moduleData.type,
            subModules: [],
            specifications: moduleData.specifications || {}
        };

        this.modules.push(newModule);
        return newModule;
    }

    /**
     * Add a submodule to a module
     * @param {string} moduleId - The ID of the module
     * @param {Object} subModule - The submodule to add
     * @returns {boolean} True if successful, false if module not found or submodule already exists
     */
    addSubModuleToModule(moduleId, subModule) {
        const moduleIndex = this.modules.findIndex(m => m.id === moduleId);

        if (moduleIndex === -1) {
            return false;
        }

        // Check if the submodule is already in the module
        const subModuleExists = this.modules[moduleIndex].subModules.some(sm => sm.id === subModule.id);

        if (subModuleExists) {
            return false;
        }

        this.modules[moduleIndex].subModules.push(subModule);
        return true;
    }

    /**
     * Remove a submodule from a module
     * @param {string} moduleId - The ID of the module
     * @param {string} subModuleId - The ID of the submodule to remove
     * @returns {boolean} True if successful, false if not found
     */
    removeSubModuleFromModule(moduleId, subModuleId) {
        const moduleIndex = this.modules.findIndex(m => m.id === moduleId);

        if (moduleIndex === -1) {
            return false;
        }

        const initialLength = this.modules[moduleIndex].subModules.length;
        this.modules[moduleIndex].subModules = this.modules[moduleIndex].subModules.filter(sm => sm.id !== subModuleId);

        return this.modules[moduleIndex].subModules.length < initialLength;
    }

    /**
     * Update an existing module
     * @param {string} moduleId - The ID of the module to update
     * @param {Object} updatedData - The updated module data
     * @returns {Object|null} The updated module or null if not found
     */
    updateModule(moduleId, updatedData) {
        const moduleIndex = this.modules.findIndex(m => m.id === moduleId);

        if (moduleIndex === -1) {
            return null;
        }

        // Preserve subModules when updating
        const subModules = this.modules[moduleIndex].subModules;

        this.modules[moduleIndex] = {
            ...this.modules[moduleIndex],
            ...updatedData,
            subModules
        };

        return this.modules[moduleIndex];
    }

    /**
     * Delete a module
     * @param {string} moduleId - The ID of the module to delete
     * @returns {boolean} True if successful, false if not found
     */
    deleteModule(moduleId) {
        const initialLength = this.modules.length;
        this.modules = this.modules.filter(m => m.id !== moduleId);
        return this.modules.length < initialLength;
    }

    /**
     * Get a module by ID
     * @param {string} moduleId - The ID of the module to retrieve
     * @returns {Object|null} The module or null if not found
     */
    getModuleById(moduleId) {
        return this.modules.find(m => m.id === moduleId) || null;
    }

    /**
     * Set the modules array (used for loading saved data)
     * @param {Array} modulesArray - Array of modules to set
     */
    setModules(modulesArray) {
        if (Array.isArray(modulesArray)) {
            this.modules = modulesArray;
        }
    }
}

window.ModelModulesBuilder = ModelModulesBuilder;